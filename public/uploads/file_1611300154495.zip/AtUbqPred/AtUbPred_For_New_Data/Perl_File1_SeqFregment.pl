open (FILE,'I:/PARVEZ/protein_file.txt')||die "$!";				## input line
    open(OUT,'>I:/PARVEZ/test_fragment.txt')||die "$!";			## output line
@tag=();


while($seq=<FILE>){

	chomp($seq);
	if ($seq=~/^\>/)
	{
	   @tag=();
	   @aa=split(/\t/, $seq);
	 
	    foreach $a(@aa){
	      if($a=~/^\>/){$proname=substr($a,1);}
	      else {$a=~s/^\#//;$tag[$a-0]="+1";}
	
	    }
	
		next;
	}
     	   
	 
	 	 $len=length($seq);
	     $gap="-------------";
	     $seq=$gap.$seq.$gap;
	     # @array=split //, $seq;

	 
	    for ($i=0; $i<=$len-1; $i++){
	           $b=substr($seq,$i+12,1);
	
		    if($b eq "K" && $tag[$i]!=1){$tag[$i]=-1;}
		     if ($tag[$i]==1){$frag=substr($seq,$i,25);print OUT "$frag\t$proname\t$i\t$b\t$tag[$i]\n";}
	         if ($tag[$i]==-1){$frag=substr($seq,$i,25);print OUT "$frag\t$proname\t$i\t$b\t$tag[$i]\n";}
	
	    }
      
  } 
close FILE;
close OUT;

	