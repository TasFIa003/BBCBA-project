	open (FILE,'E:\\Analysis_NewPTM\\test data\\Selected Test  datasets\\AraUbiSite\\test5_pos_negall.txt')||die "$!";   ##### input line
    open(OUT,'>E:\\Analysis_NewPTM\\test data\\Selected Test  datasets\\AraUbiSite\\test5_cksaap.csv')||die "$!";     ##### output line

		print OUT "class";
		for($j=1; $j<=2646; $j++){
						
		print OUT ",v$j";
		
					}
					print OUT "\n";
					
		while ($tmptest=<FILE>){
				
			@tmp=split(/\t+/ , $tmptest);
			$str=$tmp[0];$tag=$tmp[4];
			# print length($str);
			chomp $tag;
			# print OUT $tag;
			if($tag eq "+1"){print OUT "yes"}
			else{
				print OUT "no";
			}
			
			for ($k=0;$k<=5;$k++)
			{
			
				$ntotal=27-$k-1;
				@AA=qw(A C D E F G H I K L M N P Q R S T V W Y -);
				 $str=~/[A-Z]/gi;
				%cp={};
				$sum=0;
				for($i=0; $i<length($str)-$k-1; $i++){
					$a=substr($str,$i,1);
					$b=substr($str,$i+$k+1,1);
					$key=$a.$b;
					# print $key, "\n";
					$cp{$key}++;
				}
				@array=();
	
				for ($a=0;$a<=20; $a++){
					for ($b=0;$b<=20; $b++)
					{
						$key=$AA[$a].$AA[$b];
						
						$s++;
						push(@array, $cp{$key});
					}
				}
					for($j=0; $j<@array; $j++){
						$feavalue=$array[$j]/$ntotal;
						# $index=$k*441+$j+1;
						 print OUT ",$feavalue";
						#  print OUT "\t$index:$feavalue";
					}
					
			}		
		    print OUT "\n";
		}
			close FILE;
			close OUT;
