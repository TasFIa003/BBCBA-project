
data<- read.csv(file="Nonedited_one_One_ratio.csv", header=FALSE, sep=",")
dim=dim(data)[2]
dim=(dim-1)/2
i=1
g=0
final=NULL
for(i in 1:dim)
{
  v=g+2;
  g=v;
  i=i+1;
  final=rbind(final,v);
}
bbb=data[,-final]
write.csv(bbb,"one_One_ratio.csv", append = TRUE,row.names = FALSE)
