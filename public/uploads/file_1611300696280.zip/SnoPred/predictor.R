

########################directory set########################

data<- read.csv(file="will_Training_data_1-1_ratio_1500feature.csv", header=TRUE, sep=",")
TrueClass.tr<-data$class
length(TrueClass.tr)
data_test<- read.csv(file="will_Test_data_positive_negative_site_1500feature.csv", header=TRUE, sep=",")
TrueClass.tst<-data_test$class
length(TrueClass.tst)
nrow(data)
nrow(data_test)

############## Real Data Random Forest #####################

library(randomForest)

model.RFR <- randomForest(data$class ~ ., data = data)

Pred.train<- predict(model.RFR ,data[,-1])

Pred.test<- predict(model.RFR ,data_test[,-1])


#########################ROC and AUC#################

library(ROSE)

Pred.RFR.tr <- predict(model.RFR, data,"prob")
Pred.RFR.tst <- predict(model.RFR, data_test,"prob")
roc.curve(data$class,Pred.RFR.tr[,2],col = 'black', lwd = '3',main = "RF")
roc.curve(data_test$class,Pred.RFR.tst[,2],col = 'black', lwd = '3',main = "RF")
