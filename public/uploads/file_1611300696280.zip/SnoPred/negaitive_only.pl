open (FILE,'./Training_data_PTM_mus.txt')||die "$!";
open(OUT,'>./Training_data_Negative_site_29window.txt')||die "$!";
@tag=();


while($seq=<FILE>){

	chomp($seq);
	if ($seq=~/^\>/)
	{
	   @tag=();
	   @aa=split(/\t/, $seq);
	 
	    foreach $a(@aa){
	      if($a=~/^\>/){$proname=substr($a,1);}
	      else {$a=~s/^\#//;$tag[$a-1]="+1";}
	
	    }
	
		next;
	}
     	   
	 
	 	 $len=length($seq);
	     $gap="--------------";
	     $seq=$gap.$seq.$gap;
	     # @array=split //, $seq;

	 $j=0;
	    for ($i=0; $i<=$len; $i++){
	           $b=substr($seq,$i+14,1);
	$j++;
		    if($b eq "C" && $tag[$i]!=1){$tag[$i]=-1;}
		      # if ($tag[$i]==1){$frag=substr($seq,$i,27);print OUT "$frag\t$proname\t$j\t$b$j\t$tag[$i]\n";}
	        if ($tag[$i]==-1){$frag=substr($seq,$i,29);print OUT "$frag\t$proname\t$j\t$b$j\t$tag[$i]\n";}
	
	    }
      
  } 
close FILE;
close OUT;

	
	
	# if ($tag[$i]==1){$frag=substr($seq,$i,21);print "+1\t$frag\n";}