########################################################################################
#                       FEATURE SELECtion   #  Wilcox test                                         #
########################################################################################

data <- as.data.frame(read.csv("Training_data_1-1_ratio_29window.csv", header = F))
dim(data)
Data <- data[,-1]
dim(Data)
DataTr.1 <- t(Data)	
mdim1=dim(DataTr.1)[1]
pW <- NULL;
for (i in 1:mdim1) {
  pW[i] <-  wilcox.test(DataTr.1[i,])$p.value
}

position <- order(pW,decreasing = FALSE )[1:1500]     # 1st 1500 position detect
Data.wil<- t(DataTr.1[position,])
dim(Data.wil )
pWdata <- cbind(data$v1,Data.wil)
dim(pWdata)

write.csv(Data.wil,"will_Training_data_1-1_ratio_1500feature.csv", append = TRUE,row.names = TRUE)

########################################test data feature selection

data_test <- as.data.frame(read.csv("Test_data_positive_negative_site_29_window.csv", header = F))
dim(data_test)
Data <- data_test[,-1]
dim(Data)
DataTst.1 <- t(Data)	
Data.tst.wil<- t(DataTst.1[position,])
dim(Data.tst.wil )
pWdata <- cbind(data$V1,Data.tst.wil)
dim(pWdata)

write.csv(Data.tst.wil,"will_Test_data_positive_negative_site_1500feature.csv", append = TRUE,row.names = TRUE)

