####################################################################################
#                                                                                  #
# Performance Improvement of Gene Selection Method Using Outlier Modification      #
# Rule  by Md. Shahjaman et al.                                                    #
#                                                                                  #
####################################################################################

####################################################################################
#                                                                                  #
# Generate simulated dataset using R package OutMod by Md. Shahjaman et al.        #
#                                                                                  #
####################################################################################

library(OutMod)

nG=1000;n1=n2=3;var0=0.1;pde=0.1 
Simdat=Sim2Group(nG,n1,n2,var0,pde) 
xx=Simdat$outmat
TrueDE=Simdat$DEtrue 
groupid=rep(c(1,2),each=3)

#####--Outlier Data --#####
OutSimdat=xx 
OutInx=sample(1:dim(OutSimdat)[1])[1:200] 
OutCol<-sample(1:dim(OutSimdat)[2])[1] 
for (jj in 1:length(OutInx))
{OUT<-runif(length(OutCol), min = 5+max(abs(OutSimdat[OutInx[jj],])), max =10+max(abs(OutSimdat[OutInx[jj],]))) 
OutSimdat[OutInx[jj],OutCol]<-OUT}


####--Performance evaluation in absence of outliers--#########
Datao<-xx

pTtest<-NULL; 
for (j1 in 1:dim(Datao)[1]) 
{DataYY <- data.frame(YY =Datao[j1,], FactorLevels = factor(groupid)) 
pTtest[j1] <- t.test(YY~FactorLevels,data=DataYY)[[3]]}
TopDEn<-seq(nG*pde/10, pde*nG, length=10)
performanceFC_orig<-performance.eval(pTtest,TrueDE,TopDEn,decreasing=FALSE);

####--Performance evaluation in presence of outliers--#########

Datao<-OutSimdat

pTtest<-NULL; 
for (j1 in 1:dim(Datao)[1]) 
{DataYY <- data.frame(YY =Datao[j1,], FactorLevels = factor(groupid)) 
pTtest[j1] <- t.test(YY~FactorLevels,data=DataYY)[[3]]}
TopDEn<-seq(nG*pde/10, pde*nG, length=10)
performanceFC_out<-performance.eval(pTtest,TrueDE,TopDEn,decreasing=FALSE);

####--Performance evaluation in after outlier modification outliers--#########

Moddata<-OutModData(OutSimdat,groupid)$uprmat

Datao<-Moddata

pTtest<-NULL; 
for (j1 in 1:dim(Datao)[1]) 
{DataYY <- data.frame(YY =Datao[j1,], FactorLevels = factor(groupid)) 
pTtest[j1] <- t.test(YY~FactorLevels,data=DataYY)[[3]]}
TopDEn<-seq(nG*pde/10, pde*nG, length=10)
performanceFC_outmod<-performance.eval(pTtest,TrueDE,TopDEn,decreasing=FALSE);

plot(performanceFC_orig$FPR,performanceFC_orig$TPR,type="l",xlim=c(0,.07),xlab="FPR",ylab="TPR")
points(performanceFC_out$FPR,performanceFC_out$TPR,type="l",xlab="FPR",ylab="TPR",col=3)
points(performanceFC_outmod$FPR,performanceFC_outmod$TPR,type="l",xlab="FPR",ylab="TPR",col=2)

legend("bottomright",c("In absence of outliers","In presence of outliers","After outlier modification"),lwd=2,col=c(1,3,2),cex=0.8)

AUC<-round(cbind(performanceFC_orig$AUC2,performanceFC_out$AUC2,performanceFC_outmod$AUC2),3)

colnames(AUC)<-c("In absence of outliers","In presence of outliers","After outlier modification")

AUC


####################################################################################
#                                                                                  #
#                         END                                                      #
#                                                                                  #
####################################################################################








