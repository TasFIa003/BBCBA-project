
## required packages (gtools, ggplot2, factoextra, NbClust, fields)

library(gtools)
library(ggplot2)
library(factoextra)
library(NbClust)
library(fields)

## Simulated Demo toxicogenomic data matrix
x <- read.csv("DemoData.csv",row.names=1)


## Function for Logistic Probabilistic Hidden Variable Model
source("LPHVM_rCoClust.R")
rCoclstResult <- RbstCoClust(x) 


## Number of co-clusters/clusters in the dataset
nCoCluster <- rCoclstResult$nCoCluster      #names(rCoclstResult)


## Gene clusters 
GeneCluster <- rCoclstResult$GeneCluster 


## Doses of chemical compound clusters 
CompCluster <- rCoclstResult$CompCluster


## Within co-cluster mean 
CoClustMean <- rCoclstResult$CoClustMean


## Upregulated biomarker genes 
UpDEgene <- rCoclstResult$UpDEgene


## Downregulated biomarker genes 
DownDEgene <- rCoclstResult$DownDEgene


## Ranking of the biomarker gene regulatory doses of chemical compound 
RnkToxCC <- rCoclstResult$RnkToxCC


## Ranking of the probabilistic relationships between biomarker genes 
# and doses of chemical compounds 
RnkGCCrel <- rCoclstResult$RnkGCCrel


## Gene-Doses of Chemical Compound Joint Probability Matrix 
GCjoitProbability <- rCoclstResult$GCjointProb

## Please Run the following Full Code to Get the Gene-Doses of Compound Co-cluster View 

library(fields)
par(mar=c(3,5,5,6))
image(GCjoitProbability, col=colorRampPalette(c("white","gray","black"), space = "rgb")(79),axes=FALSE)
mtext(text=rownames(GCjoitProbability), side=1, line=0.3, at=seq(0,1,1/(nrow(GCjoitProbability)-1)), las=2, cex=0.8)
mtext(text=colnames(GCjoitProbability), side=2, line=0.3, at=seq(0,1,1/(ncol(GCjoitProbability)-1)), las=2, cex=0.8)
image.plot(GCjoitProbability, col=colorRampPalette(c("white","gray","black"), space = "rgb")(79),legend.only=TRUE, horizontal=F)



