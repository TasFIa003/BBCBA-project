## tm = Times outlying obs. compare to regular obs.
## PerRowOL = percentage of rows contains outlying obs. 
## PerColOL = percentage of coloms contains outlying obs.

SmDt <- function (Ge, CC)
{
x1 <- cbind(rbind(matrix(rnorm(7*5,3,0.35),7,5),matrix(rnorm(3*5,-3,0.35),3,5)),matrix(rnorm(10*5,0,0.35),10,5),
	rbind(matrix(rnorm(7*5,2.5,0.35),7,5),matrix(rnorm(3*5,-2.5,0.35),3,5)),matrix(rnorm(10*15,0,0.35),10,15))
x2 <- cbind(matrix(rnorm(10*5,0,0.35),10,5),rbind(matrix(rnorm(7*5,3,0.35),7,5),matrix(rnorm(3*5,-3,0.35),3,5)),
	matrix(rnorm(10*5,0,0.35),10,5),rbind(matrix(rnorm(7*5,2.5,0.35),7,5),matrix(rnorm(3*5,-2.5,0.35),3,5)),
	matrix(rnorm(10*10,0,0.35),10,10))
x3 <- matrix(rnorm(30*30,0,0.35),30,30)
SData <- (rbind(x1,x2,x3))
SimData <- (rbind(x1,x2,x3))

GeneName <- paste("G",1:Ge,sep="")
DrugName <- paste("C",1:CC,sep="")
DrugNameL <- paste(DrugName, "Low", sep=("_"))
DrugNameM <- paste(DrugName, "Middle", sep=("_"))
DrugNameH <- paste(DrugName, "High", sep=("_"))
DnameWdose <- c(DrugNameH, DrugNameM, DrugNameL)
dimnames(SimData) <- list(GeneName,DnameWdose)
gname <- rownames(SimData)
cname <- colnames(SimData)
	
SimDataRnd <- SimData[sample(nrow(SimData)),sample(ncol(SimData))]
GCmatAbs <- round(abs(SimDataRnd)*100)
GCmat <- round(100*(1/(1+exp(-abs(SimDataRnd)))))
		
return(list(SimData = SimData, SimDataRnd = SimDataRnd, GCmatAbs = GCmatAbs, GCmat = GCmat))
}
 

